
public class Name {
	
	   private String firstName;
	   private String lastName;
	   private String nickName;

	   public Name(String first, String last, String nick) {
		   this.firstName = first;
		   this.lastName = last;
		   this.nickName = nick;
	   }
	   
	   /*get method*/
	   public String getFirstName()
	   {
	      return firstName;
	   } 

	   public String getLastName()
	   {
	      return lastName;
	   }

	   public String getNickName()
	   {
	      return nickName;
	   }
	   
	   /*set method*/
	   public void setFirstName(String name)
	   {
		   firstName = name;
	   }
	   
	   public void setLastName(String name)
	   {
		   lastName = name;
	   }
	   
	   public void setNickName(String name)
	   {
		   nickName = name;
	   }
	   
	   @Override
	   public String toString()
	   { 
	      return String.format( "%s %s/%s",firstName, lastName, nickName ); 
	   } // end method toString
}
